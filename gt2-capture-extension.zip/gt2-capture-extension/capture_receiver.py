#!/usr/bin/env python3
r"""capture_receiver.py — local sink for the Full Wire Capture extension.

The browser extension cannot write to an arbitrary folder on its own: Chromium
(and therefore WebView2) only lets an extension drop files under the browser's
Downloads directory via chrome.downloads, and an embedded WebView2 host usually
has no download UI at all. So in "http" save mode the extension POSTs the capture
JSON here and THIS process writes it to whatever folder you choose — fully
automatic, no dialogs, works inside WebView2.

Zero dependencies (stdlib only).

USAGE
-----
  python capture_receiver.py --dir D:\captures
  python capture_receiver.py --dir ./captures --port 8782 --host 127.0.0.1

Then in the extension popup set:
  Save mode      = HTTP -> local receiver
  Receiver       = http://127.0.0.1:8782/save   (match --host/--port)
  Save folder    = D:\captures                  (optional; overrides --dir per request)

The extension sends two headers:
  X-Filename : suggested filename (sanitised here)
  X-Save-Dir : absolute folder to write into (optional; falls back to --dir)

Security: bound to 127.0.0.1 by default. The payload contains REAL cookies/
tokens (.ROBLOSECURITY, ARID) — treat written files as secret. For authorized
local defensive engineering on our own 9Router project only.
"""

from __future__ import annotations

import argparse
import json
import os
import re
import sys
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

MAX_BODY_BYTES = 64 * 1024 * 1024  # 64 MB ceiling per capture
_SAFE_NAME_RE = re.compile(r"[^A-Za-z0-9._-]+")

DEFAULT_DIR = os.environ.get("CAPTURE_DIR", r"C:\Users\ADMIN\Downloads\New folder")


def _now_stamp() -> str:
    return datetime.now(timezone.utc).isoformat().replace(":", "-").replace(".", "-")


def sanitize_filename(name: str | None) -> str:
    """Strip any path components and unsafe chars; guarantee a .json name."""
    if not name:
        return f"full-wire-capture-{_now_stamp()}.json"
    name = os.path.basename(name.replace("\\", "/"))
    name = _SAFE_NAME_RE.sub("_", name).strip("._") or "capture"
    if not name.lower().endswith(".json"):
        name += ".json"
    return name


class Handler(BaseHTTPRequestHandler):
    server_version = "GT2CaptureReceiver/1.0"
    # Folder used when a request does not specify X-Save-Dir. Set on the server.
    base_dir = DEFAULT_DIR

    def _cors(self) -> None:
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, X-Filename, X-Save-Dir")

    def _json(self, code: int, obj: dict) -> None:
        body = json.dumps(obj).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self._cors()
        self.end_headers()
        self.wfile.write(body)

    def do_OPTIONS(self) -> None:  # CORS preflight
        self.send_response(204)
        self._cors()
        self.end_headers()

    def do_GET(self) -> None:
        # Lightweight health check so the extension/user can verify the sink.
        if self.path.rstrip("/") in ("", "/health", "/ping"):
            self._json(200, {"ok": True, "service": "gt2-capture-receiver", "dir": type(self).base_dir})
        else:
            self._json(404, {"ok": False, "error": "not found"})

    def do_POST(self) -> None:
        if self.path.rstrip("/") not in ("/save", ""):
            self._json(404, {"ok": False, "error": "unknown path; POST to /save"})
            return
        try:
            length = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            length = 0
        if length <= 0:
            self._json(400, {"ok": False, "error": "empty body"})
            return
        if length > MAX_BODY_BYTES:
            self._json(413, {"ok": False, "error": f"body exceeds {MAX_BODY_BYTES} bytes"})
            return

        raw = self.rfile.read(length)
        # Validate it's JSON (don't write garbage), but persist the original bytes
        # so the on-disk file is byte-identical to what the extension produced.
        try:
            json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            self._json(400, {"ok": False, "error": f"invalid JSON: {exc}"})
            return

        target_dir = (self.headers.get("X-Save-Dir") or "").strip() or type(self).base_dir
        filename = sanitize_filename(self.headers.get("X-Filename"))
        try:
            os.makedirs(target_dir, exist_ok=True)
            path = os.path.join(target_dir, filename)
            # Avoid clobbering if two captures land in the same millisecond.
            if os.path.exists(path):
                stem, ext = os.path.splitext(filename)
                path = os.path.join(target_dir, f"{stem}-{_now_stamp()}{ext}")
            with open(path, "wb") as f:
                f.write(raw)
        except OSError as exc:
            self._json(500, {"ok": False, "error": f"write failed: {exc}"})
            return

        abspath = os.path.abspath(path)
        print(f"[saved] {abspath}  ({len(raw)} bytes)", flush=True)
        self._json(200, {"ok": True, "path": abspath, "bytes": len(raw)})

    def log_message(self, fmt: str, *args) -> None:  # quieter default logging
        sys.stderr.write("  " + (fmt % args) + "\n")


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Local HTTP sink for the Full Wire Capture extension.")
    ap.add_argument("--dir", default=DEFAULT_DIR, help="default folder to write captures into")
    ap.add_argument("--host", default="127.0.0.1", help="bind host (default 127.0.0.1)")
    ap.add_argument("--port", type=int, default=8782, help="bind port (default 8782)")
    args = ap.parse_args(argv)

    base_dir = os.path.abspath(args.dir)
    os.makedirs(base_dir, exist_ok=True)
    Handler.base_dir = base_dir

    httpd = ThreadingHTTPServer((args.host, args.port), Handler)
    print(
        f"gt2-capture-receiver listening on http://{args.host}:{args.port}\n"
        f"  writing captures to: {base_dir}\n"
        f"  extension endpoint : http://{args.host}:{args.port}/save\n"
        "  (Ctrl+C to stop)",
        flush=True,
    )
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nstopping.", flush=True)
    finally:
        httpd.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
