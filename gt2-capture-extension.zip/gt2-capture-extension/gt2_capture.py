#!/usr/bin/env python3
"""Full Wire Capture (Python port of the gt2-capture-extension).

Drives the Chrome DevTools Protocol (CDP) DIRECTLY over a raw WebSocket — no
external packages, no Selenium, no browser extension. Captures the EXACT bytes
every request puts on the wire (header names + order, request body, response
body) for a Chrome tab, tags Arkose/Roblox endpoints, snapshots the live frame
topology on the trust-deciding /fc/gt2/ POST, and AUTO-EXPORTS the moment a
/challenge/continue request finishes with HTTP 200 — mirroring the extension's
auto mode. Output is the SAME JSON schema (schema_version "2.0.0") so existing
diff tooling (diff_bda_schema.py, the inapp import path) consumes it unchanged.

WHY CDP and not webRequest/requests: webRequest cannot read POST/response bodies
and strips sec-ch-ua* client hints; a plain HTTP client cannot observe the real
browser's on-wire header order or its JS-generated BDA. CDP's Network domain
exposes the ground-truth bytes — exactly what the extension relied on.

USAGE
-----
  # Launch a fresh Chrome wired for CDP, auto-attach on the challenge page, and
  # auto-export when /challenge/continue returns 200 (Ctrl+C also exports):
  python gt2_capture.py --launch

  # Attach to a Chrome already started with --remote-debugging-port=9222:
  python gt2_capture.py --attach 9222

  # Pick the tab by URL substring / custom output prefix:
  python gt2_capture.py --launch --match roblox.com --out my-capture.json

SECURITY: the export contains REAL cookies/tokens (.ROBLOSECURITY, ARID, csrf).
Treat the file as secret and redact before sharing or committing. For authorized,
local defensive engineering against our own 9Router project only.
"""

from __future__ import annotations

import argparse
import base64
import json
import os
import re
import shutil
import socket
import struct
import subprocess
import tempfile
import threading
import time
import urllib.request
from datetime import datetime, timezone
from typing import Any, Callable

PROTOCOL_NOTE = "Full on-wire HTTP capture via CDP (every request)."
SCHEMA_VERSION = "2.0.0"

# Endpoints we TAG (capture is never limited to these — every request is kept).
ARKOSE_RE = re.compile(
    r"arkoselabs|/fc/(gt2|a|ca)/|/v2/[^/]+/api\.js|enforcement\.[0-9a-f]+\.html|funcaptcha|/pows?/",
    re.I,
)
ROBLOX_CHALLENGE_RE = re.compile(
    r"/challenge/(v1/)?continue|apis\.roblox\.com/challenge|challenge/cdn|hybrid", re.I
)
ROBLOX_RE = re.compile(r"roblox\.com|rbxcdn\.com|rbx\.com", re.I)
GT2_RE = re.compile(r"/fc/gt2/", re.I)
# Roblox challenge surface (auto-attach) and redeem endpoint (auto-export on 200).
HYBRID_RE = re.compile(r"roblox\.com/challenge/cdn/hybrid", re.I)
CONTINUE_RE = re.compile(r"/challenge/(v1/)?continue", re.I)

MAX_BODY_CAPTURE_BYTES = 5 * 1024 * 1024


def classify(url: str) -> str:
    u = url or ""
    if ARKOSE_RE.search(u):
        return "arkose"
    if ROBLOX_CHALLENGE_RE.search(u):
        return "roblox-challenge"
    if ROBLOX_RE.search(u):
        return "roblox"
    return "other"


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


# ---------------------------------------------------------------------------
# Minimal RFC 6455 WebSocket client (text frames, client-masked) — stdlib only.
# ---------------------------------------------------------------------------
class WebSocket:
    """Blocking WebSocket client good enough for CDP: client->server text frames
    are masked per spec; server frames are read (incl. continuation fragments and
    control frames). CDP payloads can be multi-MB (response bodies), so frame
    reassembly and large reads are handled."""

    _OPCODE_CONT = 0x0
    _OPCODE_TEXT = 0x1
    _OPCODE_BIN = 0x2
    _OPCODE_CLOSE = 0x8
    _OPCODE_PING = 0x9
    _OPCODE_PONG = 0xA

    def __init__(self, url: str, timeout: float = 30.0):
        if not url.startswith("ws://"):
            raise ValueError(f"only ws:// supported, got {url!r}")
        rest = url[len("ws://"):]
        hostport, _, path = rest.partition("/")
        host, _, port = hostport.partition(":")
        self._host = host
        self._port = int(port or 80)
        self._path = "/" + path
        self._sock = socket.create_connection((self._host, self._port), timeout=timeout)
        self._sock.settimeout(timeout)
        self._recv_buf = b""
        self._send_lock = threading.Lock()
        self._handshake()

    def _handshake(self) -> None:
        key = base64.b64encode(os.urandom(16)).decode("ascii")
        req = (
            f"GET {self._path} HTTP/1.1\r\n"
            f"Host: {self._host}:{self._port}\r\n"
            "Upgrade: websocket\r\n"
            "Connection: Upgrade\r\n"
            f"Sec-WebSocket-Key: {key}\r\n"
            "Sec-WebSocket-Version: 13\r\n"
            "\r\n"
        )
        self._sock.sendall(req.encode("ascii"))
        header = b""
        while b"\r\n\r\n" not in header:
            chunk = self._sock.recv(4096)
            if not chunk:
                raise ConnectionError("socket closed during WS handshake")
            header += chunk
        head, _, extra = header.partition(b"\r\n\r\n")
        if b"101" not in head.split(b"\r\n", 1)[0]:
            raise ConnectionError(f"WS handshake failed: {head[:120]!r}")
        self._recv_buf = extra

    def _read_exact(self, n: int) -> bytes:
        while len(self._recv_buf) < n:
            chunk = self._sock.recv(65536)
            if not chunk:
                raise ConnectionError("socket closed")
            self._recv_buf += chunk
        out, self._recv_buf = self._recv_buf[:n], self._recv_buf[n:]
        return out

    def _read_frame(self) -> tuple[tuple[int, int], bytes]:
        b0, b1 = self._read_exact(2)
        fin = b0 & 0x80
        opcode = b0 & 0x0F
        masked = b1 & 0x80
        length = b1 & 0x7F
        if length == 126:
            length = struct.unpack(">H", self._read_exact(2))[0]
        elif length == 127:
            length = struct.unpack(">Q", self._read_exact(8))[0]
        mask = self._read_exact(4) if masked else b""
        payload = self._read_exact(length) if length else b""
        if masked and payload:
            payload = bytes(b ^ mask[i % 4] for i, b in enumerate(payload))
        return (opcode, fin), payload

    def recv(self) -> str:
        """Return the next full text message, transparently handling
        fragmentation and answering ping/close control frames."""
        frags: list[bytes] = []
        while True:
            (opcode, fin), payload = self._read_frame()
            if opcode == self._OPCODE_PING:
                self._send_raw(self._OPCODE_PONG, payload)
                continue
            if opcode == self._OPCODE_CLOSE:
                raise ConnectionError("server sent close frame")
            if opcode == self._OPCODE_PONG:
                continue
            frags.append(payload)
            if fin:
                break
        return b"".join(frags).decode("utf-8", "replace")

    def _send_raw(self, opcode: int, data: bytes) -> None:
        fin_op = 0x80 | opcode
        length = len(data)
        header = bytearray([fin_op])
        mask = os.urandom(4)
        if length < 126:
            header.append(0x80 | length)
        elif length < 65536:
            header.append(0x80 | 126)
            header += struct.pack(">H", length)
        else:
            header.append(0x80 | 127)
            header += struct.pack(">Q", length)
        header += mask
        masked = bytes(b ^ mask[i % 4] for i, b in enumerate(data))
        with self._send_lock:
            self._sock.sendall(bytes(header) + masked)

    def send(self, text: str) -> None:
        self._send_raw(self._OPCODE_TEXT, text.encode("utf-8"))

    def close(self) -> None:
        try:
            self._send_raw(self._OPCODE_CLOSE, b"")
        except OSError:
            pass
        try:
            self._sock.close()
        except OSError:
            pass


# ---------------------------------------------------------------------------
# CDP client: one WebSocket to the browser endpoint, flat-session multiplexing.
# ---------------------------------------------------------------------------
class CDPClient:
    """Talks CDP over a single browser-level WebSocket. Uses flatten mode
    (Target.setAutoAttach flatten=true) so every child target (the Arkose
    enforcement iframe is an out-of-process frame / OOPIF) is reachable via a
    sessionId on the same socket."""

    def __init__(self, ws_url: str):
        self._ws = WebSocket(ws_url, timeout=60.0)
        self._next_id = 0
        self._id_lock = threading.Lock()
        self._pending: dict[int, dict[str, Any]] = {}
        self._pending_lock = threading.Lock()
        self._handlers: list[Callable[[str, dict[str, Any], str | None], None]] = []
        self._running = True
        self._reader = threading.Thread(target=self._read_loop, daemon=True)
        self._reader.start()

    def on_event(self, handler: Callable[[str, dict[str, Any], str | None], None]) -> None:
        self._handlers.append(handler)

    def _read_loop(self) -> None:
        while self._running:
            try:
                raw = self._ws.recv()
            except (ConnectionError, OSError):
                break
            try:
                msg = json.loads(raw)
            except json.JSONDecodeError:
                continue
            mid = msg.get("id")
            if mid is not None:
                with self._pending_lock:
                    slot = self._pending.get(mid)
                if slot is not None:
                    slot["result"] = msg
                    slot["event"].set()
                continue
            method = msg.get("method")
            if method:
                session_id = msg.get("sessionId")
                params = msg.get("params") or {}
                for h in self._handlers:
                    try:
                        h(method, params, session_id)
                    except Exception:
                        pass

    def send(
        self,
        method: str,
        params: dict[str, Any] | None = None,
        session_id: str | None = None,
        timeout: float = 30.0,
    ) -> dict[str, Any]:
        with self._id_lock:
            self._next_id += 1
            mid = self._next_id
        payload: dict[str, Any] = {"id": mid, "method": method, "params": params or {}}
        if session_id:
            payload["sessionId"] = session_id
        ev = threading.Event()
        with self._pending_lock:
            self._pending[mid] = {"event": ev, "result": None}
        self._ws.send(json.dumps(payload))
        if not ev.wait(timeout):
            with self._pending_lock:
                self._pending.pop(mid, None)
            raise TimeoutError(f"CDP {method} timed out after {timeout}s")
        with self._pending_lock:
            slot = self._pending.pop(mid, None)
        result = (slot or {}).get("result") or {}
        if "error" in result:
            raise RuntimeError(f"CDP {method} error: {result['error']}")
        return result.get("result") or {}

    def try_send(self, *a: Any, **kw: Any) -> dict[str, Any]:
        """Best-effort send: swallow errors/timeouts (domains some targets lack)."""
        try:
            return self.send(*a, **kw)
        except (RuntimeError, TimeoutError, ConnectionError, OSError):
            return {}

    def close(self) -> None:
        self._running = False
        self._ws.close()


# ---------------------------------------------------------------------------
# Capture engine — mirrors background.js record shape & semantics 1:1.
# ---------------------------------------------------------------------------
def headers_to_ordered_array(headers_obj: Any) -> list[dict[str, str]]:
    """CDP headers come as an insertion-ordered object; preserve that exact
    on-wire sequence as an ordered [{name,value}] array."""
    if not isinstance(headers_obj, dict):
        return []
    return [{"name": k, "value": str(v)} for k, v in headers_obj.items()]


_TOPOLOGY_EXPR = (
    "JSON.stringify({"
    "ancestorOrigins: Array.prototype.slice.call(window.location.ancestorOrigins||[]),"
    "href: window.location.href,"
    "referrer: document.referrer,"
    "depth: (function(){var d=0,w=window;try{while(w!==w.parent){d++;w=w.parent;}}catch(e){}return d;})(),"
    "topHref: (function(){try{return window.top.location.href;}catch(e){return '<cross-origin>';}})(),"
    "inIframe: window.self!==window.top,"
    "aridLocalStorage: (function(){try{var o={};for(var i=0;i<localStorage.length;i++){var k=localStorage.key(i);if(/arid|x-ark/i.test(k))o[k]=localStorage.getItem(k);}return o;}catch(e){return {_err:String(e)};}})(),"
    "allLocalStorageKeys: (function(){try{var a=[];for(var i=0;i<localStorage.length;i++)a.push(localStorage.key(i));return a;}catch(e){return [];}})()"
    "})"
)
_IDB_EXPR = (
    "(async function(){try{"
    "var dbs=(indexedDB.databases?await indexedDB.databases():[]);"
    "var out={databases:dbs.map(function(d){return d.name;}),stores:{}};"
    "for(var di=0;di<dbs.length;di++){var nm=dbs[di].name;"
    "await new Promise(function(res){var rq=indexedDB.open(nm);rq.onsuccess=function(){var db=rq.result;try{var names=Array.prototype.slice.call(db.objectStoreNames);"
    "var tx=db.transaction(names,'readonly');var pending=names.length;if(!pending){res();return;}"
    "names.forEach(function(sn){var st=tx.objectStore(sn);var gr=st.getAll();var kr=st.getAllKeys();"
    "gr.onsuccess=function(){kr.onsuccess=function(){out.stores[nm+'/'+sn]={keys:kr.result,values:gr.result};if(--pending<=0)res();};};"
    "gr.onerror=function(){if(--pending<=0)res();};});}catch(e){out.stores[nm]={_err:String(e)};res();}};rq.onerror=function(){res();};});}"
    "return out;}catch(e){return {_err:String(e)};}})()"
)
_FRAME_CHALLENGE_RE = re.compile(r"arkoselabs|enforcement|/fc/|funcaptcha|challenge/cdn|hybrid", re.I)


class Capture:
    """Holds all records keyed by (sessionId, requestId). Auto-exports once a
    /challenge/continue finishes with HTTP 200 (mirrors the extension)."""

    def __init__(self, cdp: CDPClient, out_path: str, verbose: bool = True, auto: bool = True):
        self._cdp = cdp
        self._out_path = out_path
        self._verbose = verbose
        self._auto = auto
        self._records: dict[tuple[str, str], dict[str, Any]] = {}
        self._order: list[tuple[str, str]] = []
        self._lock = threading.Lock()
        self._page_session: str | None = None
        self._tab_id: str = ""
        self._auto_exported = False
        self.exported_event = threading.Event()
        cdp.on_event(self._on_event)

    def set_tab_id(self, tab_id: str) -> None:
        self._tab_id = tab_id

    # -- session plumbing ---------------------------------------------------
    def enable_target(self, session_id: str | None, is_page: bool) -> None:
        self._cdp.try_send(
            "Network.enable",
            {"maxResourceBufferSize": 200 * 1024 * 1024, "maxTotalBufferSize": 500 * 1024 * 1024},
            session_id=session_id,
        )
        self._cdp.try_send("Page.enable", {}, session_id=session_id)
        self._cdp.try_send("Runtime.enable", {}, session_id=session_id)
        self._cdp.try_send(
            "Target.setAutoAttach",
            {"autoAttach": True, "waitForDebuggerOnStart": False, "flatten": True},
            session_id=session_id,
        )
        if is_page and self._page_session is None:
            self._page_session = session_id or ""

    # -- record helpers -----------------------------------------------------
    def _key(self, session_id: str | None, request_id: str) -> tuple[str, str]:
        return (session_id or "", request_id)

    def _get(self, session_id: str | None, request_id: str) -> dict[str, Any] | None:
        return self._records.get(self._key(session_id, request_id))

    def record_count(self) -> int:
        with self._lock:
            return len(self._order)

    def counts(self) -> dict[str, int]:
        c = {"arkose": 0, "roblox-challenge": 0, "roblox": 0, "other": 0}
        with self._lock:
            for k in self._order:
                cat = self._records[k].get("category", "other")
                c[cat] = c.get(cat, 0) + 1
        return c

    def export_records(self) -> list[dict[str, Any]]:
        with self._lock:
            return [self._records[k] for k in self._order]

    # -- the CDP event pump (mirrors background.js onEvent switch) ----------
    def _on_event(self, method: str, params: dict[str, Any], session_id: str | None) -> None:
        if method == "Target.attachedToTarget":
            info = params.get("targetInfo") or {}
            child_session = params.get("sessionId")
            self.enable_target(child_session, is_page=(info.get("type") == "page"))
            return
        if method == "Network.requestWillBeSent":
            self._on_request_will_be_sent(params, session_id)
        elif method == "Network.requestWillBeSentExtraInfo":
            rec = self._get(session_id, params.get("requestId"))
            if rec is not None:
                rec["wireRequestHeaders"] = headers_to_ordered_array(params.get("headers"))
                rec["connectTiming"] = params.get("connectTiming")
        elif method == "Network.responseReceived":
            rec = self._get(session_id, params.get("requestId"))
            if rec is not None:
                resp = params.get("response") or {}
                rec["status"] = resp.get("status")
                rec["statusText"] = resp.get("statusText")
                rec["responseHeaders"] = headers_to_ordered_array(resp.get("headers"))
                rec["remoteIPAddress"] = resp.get("remoteIPAddress")
                rec["protocol"] = resp.get("protocol")
                rec["mimeType"] = resp.get("mimeType")
                if self._auto and CONTINUE_RE.search(rec.get("url") or "") and resp.get("status") == 200:
                    self._auto_export("continue-200")
        elif method == "Network.responseReceivedExtraInfo":
            rec = self._get(session_id, params.get("requestId"))
            if rec is not None:
                rec["wireResponseHeaders"] = headers_to_ordered_array(params.get("headers"))
                rec["statusCodeExtra"] = params.get("statusCode")
                if self._auto and CONTINUE_RE.search(rec.get("url") or "") and params.get("statusCode") == 200:
                    self._auto_export("continue-200")
        elif method == "Network.loadingFinished":
            self._on_loading_finished(params, session_id)
        elif method == "Network.loadingFailed":
            rec = self._get(session_id, params.get("requestId"))
            if rec is not None:
                rec["done"] = True
                rec["failed"] = True
                rec["errorText"] = params.get("errorText")
                rec["canceled"] = params.get("canceled")

    def _on_request_will_be_sent(self, params: dict[str, Any], session_id: str | None) -> None:
        req = params.get("request") or {}
        url = req.get("url") or ""
        request_id = params.get("requestId")
        key = self._key(session_id, request_id)
        with self._lock:
            rec = self._records.get(key)
            if rec is None:
                rec = {}
                self._records[key] = rec
                self._order.append(key)
        rec["requestId"] = request_id
        rec["sessionId"] = session_id or ""
        rec["url"] = url
        rec["category"] = classify(url)
        rec["method"] = req.get("method")
        rec["requestTime"] = params.get("wallTime")
        rec["documentURL"] = params.get("documentURL")
        rec["type"] = params.get("type")
        rec["initiator"] = params.get("initiator")
        rec["requestHeadersHL"] = headers_to_ordered_array(req.get("headers"))
        rec["hasPostData"] = bool(req.get("hasPostData"))
        if req.get("postData") is not None:
            rec["postData"] = req.get("postData")

        if rec["hasPostData"] and rec.get("postData") is None:
            res = self._cdp.try_send(
                "Network.getRequestPostData", {"requestId": request_id}, session_id=session_id
            )
            if isinstance(res.get("postData"), str):
                rec["postData"] = res["postData"]

        if self._verbose and rec["category"] in ("arkose", "roblox-challenge"):
            print(f"  [{rec['category']:16}] {rec['method']} {url[:90]}", flush=True)

        if GT2_RE.search(url):
            try:
                rec["topology_truth"] = self._capture_topology()
            except Exception as exc:
                rec["topology_truth"] = {"error": str(exc)}

    def _on_loading_finished(self, params: dict[str, Any], session_id: str | None) -> None:
        rec = self._get(session_id, params.get("requestId"))
        if rec is None:
            return
        rec["done"] = True
        encoded = params.get("encodedDataLength")
        rec["encodedDataLength"] = encoded
        if isinstance(encoded, (int, float)) and encoded > MAX_BODY_CAPTURE_BYTES:
            rec["responseBody"] = f"<skipped: {int(encoded)} bytes exceeds {MAX_BODY_CAPTURE_BYTES}>"
            return
        res = self._cdp.try_send(
            "Network.getResponseBody", {"requestId": params.get("requestId")}, session_id=session_id
        )
        body = res.get("body")
        if isinstance(body, str):
            rec["responseBody"] = f"base64:{body}" if res.get("base64Encoded") else body

    # -- topology truth (frame tree + per-frame ancestorOrigins/ARID) -------
    def _capture_topology(self) -> dict[str, Any]:
        out: dict[str, Any] = {"capturedAt": _now_iso(), "frameTree": None, "arkoseFrames": []}
        sess = self._page_session
        try:
            tree = self._cdp.send("Page.getFrameTree", {}, session_id=sess, timeout=10.0)
        except (RuntimeError, TimeoutError) as exc:
            out["error"] = "getFrameTree failed: " + str(exc)
            return out

        flat: list[dict[str, Any]] = []

        def walk(node: dict[str, Any], parent_id: str | None, depth: int) -> None:
            f = node.get("frame") or {}
            flat.append({"frameId": f.get("id"), "parentId": parent_id, "url": f.get("url") or "", "depth": depth})
            for child in node.get("childFrames") or []:
                walk(child, f.get("id"), depth + 1)

        ft = tree.get("frameTree")
        if ft:
            walk(ft, None, 0)
        out["frameTree"] = flat

        for fr in flat:
            url = fr.get("url") or ""
            is_challenge = bool(_FRAME_CHALLENGE_RE.search(url))
            entry: dict[str, Any] = {
                "frameId": fr["frameId"],
                "url": url,
                "depth": fr["depth"],
                "isChallenge": is_challenge,
            }
            try:
                ctx = self._cdp.send(
                    "Page.createIsolatedWorld",
                    {"frameId": fr["frameId"], "worldName": "wirecap", "grantUniveralAccess": False},
                    session_id=sess,
                    timeout=10.0,
                )
                ctx_id = ctx.get("executionContextId")
                ev = self._cdp.send(
                    "Runtime.evaluate",
                    {"expression": _TOPOLOGY_EXPR, "contextId": ctx_id, "returnByValue": True},
                    session_id=sess,
                    timeout=10.0,
                )
                raw_val = (ev.get("result") or {}).get("value")
                try:
                    parsed = json.loads(raw_val) if isinstance(raw_val, str) else None
                except (TypeError, ValueError):
                    parsed = None

                idb_dump = None
                try:
                    idb_ev = self._cdp.send(
                        "Runtime.evaluate",
                        {"expression": _IDB_EXPR, "contextId": ctx_id, "returnByValue": True, "awaitPromise": True},
                        session_id=sess,
                        timeout=15.0,
                    )
                    idb_dump = (idb_ev.get("result") or {}).get("value")
                except (RuntimeError, TimeoutError):
                    idb_dump = None

                entry["topology"] = parsed if parsed is not None else raw_val
                entry["indexedDB"] = idb_dump
            except (RuntimeError, TimeoutError) as exc:
                entry["error"] = str(exc)
            out["arkoseFrames"].append(entry)
        return out

    # -- export -------------------------------------------------------------
    def build_payload(self, extra: dict[str, Any] | None = None) -> dict[str, Any]:
        records = self.export_records()
        payload = {
            "captured_at": _now_iso(),
            "tab_id": self._tab_id,
            "record_count": len(records),
            "schema_version": SCHEMA_VERSION,
            "note": (
                f"{PROTOCOL_NOTE} wireRequestHeaders/wireResponseHeaders = authoritative "
                "header order/values. postData = raw request body. responseBody = response "
                "(base64: prefix when binary). category = arkose|roblox-challenge|roblox|other. "
                "topology_truth attached to /fc/gt2/. WARNING: contains real cookies/tokens "
                "(.ROBLOSECURITY, ARID) — handle as secret, redact before sharing."
            ),
            "records": records,
        }
        if extra:
            payload.update(extra)
        return payload

    def _export_path(self, suffix: str = "") -> str:
        base, ext = os.path.splitext(self._out_path)
        ext = ext or ".json"
        if suffix:
            return f"{base}-{suffix}{ext}"
        return f"{base}{ext}"

    def write_export(self, path: str, extra: dict[str, Any] | None = None) -> str:
        payload = self.build_payload(extra)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(payload, f, ensure_ascii=False, indent=2)
        c = self.counts()
        print(
            f"\nexported {payload['record_count']} records -> {path}\n"
            f"  ark {c['arkose']} · rbx-chal {c['roblox-challenge']} · "
            f"rbx {c['roblox']} · other {c['other']}",
            flush=True,
        )
        return path

    def _auto_export(self, reason: str) -> None:
        if self._auto_exported:
            return
        self._auto_exported = True
        stamp = _now_iso().replace(":", "-").replace(".", "-")
        path = self._export_path(f"auto-{stamp}")
        try:
            self.write_export(path, extra={"auto_export": {"reason": reason, "at": _now_iso()}})
            print(f"[AUTO] {reason}: capture exported automatically.", flush=True)
            self.exported_event.set()
        except OSError:
            self._auto_exported = False  # re-arm for a later continue-200


# ---------------------------------------------------------------------------
# Chrome discovery / launch + CDP target endpoints.
# ---------------------------------------------------------------------------
def _http_json(url: str, timeout: float = 5.0) -> Any:
    with urllib.request.urlopen(url, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))


def _find_chrome() -> str | None:
    env = os.getenv("CHROME_PATH")
    if env and os.path.exists(env):
        return env
    candidates = [
        r"C:\Program Files\Google\Chrome\Application\chrome.exe",
        r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
        os.path.expandvars(r"%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"),
        r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
        r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
    ]
    for c in candidates:
        if c and os.path.exists(c):
            return c
    for name in ("chrome", "google-chrome", "chromium", "chromium-browser", "msedge"):
        found = shutil.which(name)
        if found:
            return found
    return None


def launch_chrome(port: int, start_url: str | None) -> subprocess.Popen:
    exe = _find_chrome()
    if not exe:
        raise SystemExit(
            "Chrome/Edge not found. Set CHROME_PATH or use --attach with a browser "
            "already started with --remote-debugging-port."
        )
    profile_dir = os.path.join(tempfile.gettempdir(), f"gt2cap-profile-{port}")
    args = [
        exe,
        f"--remote-debugging-port={port}",
        f"--user-data-dir={profile_dir}",
        "--no-first-run",
        "--no-default-browser-check",
        "--new-window",
    ]
    if start_url:
        args.append(start_url)
    print(f"launching: {exe}\n  port={port} profile={profile_dir}", flush=True)
    return subprocess.Popen(args)


def wait_for_devtools(port: int, timeout: float = 30.0) -> str:
    deadline = time.time() + timeout
    last_err: Exception | None = None
    while time.time() < deadline:
        try:
            ver = _http_json(f"http://127.0.0.1:{port}/json/version")
            ws = ver.get("webSocketDebuggerUrl")
            if ws:
                return ws
        except Exception as exc:
            last_err = exc
        time.sleep(0.3)
    raise SystemExit(f"DevTools endpoint on :{port} not ready ({last_err})")


def pick_page_target(port: int, match: str | None) -> dict[str, Any]:
    pages = [t for t in _http_json(f"http://127.0.0.1:{port}/json") if t.get("type") == "page"]
    if not pages:
        raise SystemExit("no page targets found; open a tab in the browser first")
    if match:
        for t in pages:
            if match.lower() in (t.get("url") or "").lower():
                return t
    if len(pages) == 1:
        return pages[0]
    print("\nMultiple tabs open — pick one:")
    for i, t in enumerate(pages):
        print(f"  [{i}] {(t.get('title') or '')[:40]:40} {t.get('url','')[:70]}")
    while True:
        sel = input("tab index: ").strip()
        if sel.isdigit() and 0 <= int(sel) < len(pages):
            return pages[int(sel)]


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(
        description="Full wire capture via CDP (Python port of gt2-capture-extension).",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    g = ap.add_mutually_exclusive_group()
    g.add_argument("--launch", action="store_true", help="launch a fresh Chrome wired for CDP")
    g.add_argument("--attach", type=int, metavar="PORT", help="attach to a Chrome already on this debug port")
    ap.add_argument("--port", type=int, default=9222, help="debug port for --launch (default 9222)")
    ap.add_argument("--url", default="https://www.roblox.com/login", help="start URL when --launch")
    ap.add_argument("--match", default=None, help="pick the tab whose URL contains this substring")
    ap.add_argument("--out", default=None, help="output JSON path (default full-wire-capture-<ts>.json)")
    ap.add_argument("--no-auto", action="store_true", help="disable auto-export on /challenge/continue 200")
    ap.add_argument("--quiet", action="store_true", help="don't print arkose/roblox requests live")
    args = ap.parse_args(argv)

    proc: subprocess.Popen | None = None
    if args.attach:
        port = args.attach
    else:
        port = args.port
        proc = launch_chrome(port, args.url if args.launch else None)

    ws_url = wait_for_devtools(port)
    print(f"connected to DevTools on :{port}", flush=True)

    out_path = args.out or f"full-wire-capture-{_now_iso().replace(':', '-').replace('.', '-')}.json"
    cdp = CDPClient(ws_url)
    cap = Capture(cdp, out_path, verbose=not args.quiet, auto=not args.no_auto)

    cdp.send("Target.setAutoAttach", {"autoAttach": True, "waitForDebuggerOnStart": False, "flatten": True})

    target = pick_page_target(port, args.match)
    tab_id = target.get("id") or ""
    cap.set_tab_id(tab_id)
    try:
        attach_res = cdp.send("Target.attachToTarget", {"targetId": tab_id, "flatten": True})
        cap.enable_target(attach_res.get("sessionId"), is_page=True)
    except RuntimeError as exc:
        print(f"warning: could not attach to chosen tab ({exc}); relying on auto-attach", flush=True)

    print(
        "\nCAPTURING. In the browser: open the Roblox challenge page and solve the\n"
        "Arkose challenge through to /challenge/continue. A JSON auto-exports on the\n"
        "continue-200; Ctrl+C also exports the current capture.\n",
        flush=True,
    )

    try:
        while not cap.exported_event.is_set():
            time.sleep(1.0)
            c = cap.counts()
            print(
                f"\r  reqs {cap.record_count():5} | ark {c['arkose']} · "
                f"rbx-chal {c['roblox-challenge']} · rbx {c['roblox']} · other {c['other']}   ",
                end="",
                flush=True,
            )
        # Give late events a beat to land, then nothing more to do.
        time.sleep(0.5)
    except KeyboardInterrupt:
        print("\n^C — exporting current capture.", flush=True)
        cap.write_export(out_path)

    cdp.close()
    if proc is not None:
        print("(launched browser left open; close it manually if done)", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
