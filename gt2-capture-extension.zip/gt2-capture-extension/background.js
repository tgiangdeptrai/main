// Full Wire Capture — background service worker (MV3)
//
// Why chrome.debugger (CDP) and not chrome.webRequest:
//   webRequest cannot read POST bodies or response bodies and strips the
//   sec-ch-ua* client-hint headers ("unsafe" headers). The DevTools Protocol
//   Network domain exposes the EXACT bytes the browser puts on the wire —
//   header names, values, insertion order, raw request body, and the full
//   response body — the ground-truth we diff the solver against.
//
// This build captures EVERY request the tab makes (no endpoint filter) so the
// entire API surface (headers + payload + response) is recorded, while still
// tagging Arkose/Roblox endpoints and attaching live frame topology to the
// trust-deciding /fc/gt2/ POST.

const PROTOCOL_VERSION = "1.3";

// Endpoints we tag (for quick reading / filtering in the export). Capture is
// NOT limited to these — every request is recorded.
const ARKOSE_RE = /arkoselabs|\/fc\/(gt2|a|ca)\/|\/v2\/[^/]+\/api\.js|enforcement\.[0-9a-f]+\.html|funcaptcha|\/pows?\//i;
const ROBLOX_CHALLENGE_RE = /\/challenge\/(v1\/)?continue|apis\.roblox\.com\/challenge|challenge\/cdn|hybrid/i;
const ROBLOX_RE = /roblox\.com|rbxcdn\.com|rbx\.com/i;
const GT2_RE = /\/fc\/gt2\//i;
// The Roblox challenge redeem endpoint. A 200 here means the captcha token was
// accepted (join proceeds); a 403 is the flagged-token failure. We auto-export
// the moment we observe a continue request finish with HTTP 200.
const CONTINUE_RE = /\/challenge\/(v1\/)?continue/i;
// The Roblox in-app/web challenge surface. When a tab navigates here the Arkose
// captcha flow is starting, so in AUTO mode we attach the debugger immediately
// (path-only match — the query string carries a per-challenge blob/id and is
// intentionally ignored so detection is stable across challenges).
const HYBRID_RE = /roblox\.com\/challenge\/cdn\/hybrid/i;

// Auto mode: when ON, the worker (1) auto-attaches the debugger to any Roblox
// tab as it navigates, and (2) auto-exports the full capture to a downloaded
// JSON the instant a /challenge/continue request finishes with status 200.
// Persisted in chrome.storage.local so it survives service-worker restarts.
let AUTO_MODE = true;
// Where auto-exported captures are written. WebView2 (and Chromium generally)
// forbid an extension from writing an ABSOLUTE path via chrome.downloads — it
// can only drop relative names under the browser's Downloads dir, which is
// useless when the host app embeds WebView2 with no real download UI. So the
// primary save path POSTs the JSON to a tiny LOCAL receiver
// (capture_receiver.py) that writes the file to ANY folder you configure.
//   saveMode "http"     -> POST to SAVE_ENDPOINT (works on WebView2; arbitrary dir)
//   saveMode "download" -> chrome.downloads.download (Chrome only; Downloads dir)
//   saveMode "both"     -> try http, then also download as a backup
// SAVE_DIR is sent to the receiver as a header so the folder is chosen here.
let SAVE_MODE = "http";
let SAVE_ENDPOINT = "http://127.0.0.1:8782/save";
let SAVE_DIR = "C:\\Users\\ADMIN\\Downloads\\New folder";   // default target folder
let SAVE_FILENAME_PREFIX = "full-wire-capture";

const SAVE_DEFAULTS = {
  autoMode: true,
  saveMode: "http",
  saveEndpoint: "http://127.0.0.1:8782/save",
  saveDir: "C:\\Users\\ADMIN\\Downloads\\New folder",
  saveFilenamePrefix: "full-wire-capture",
};

// Tabs where we auto-attached (so we can avoid fighting a manual stop).
const autoAttachedTabs = new Set();

function loadAutoMode() {
  try {
    chrome.storage.local.get(SAVE_DEFAULTS, (v) => {
      v = v || {};
      AUTO_MODE = !!v.autoMode;
      SAVE_MODE = v.saveMode || "http";
      SAVE_ENDPOINT = v.saveEndpoint || SAVE_DEFAULTS.saveEndpoint;
      SAVE_DIR = v.saveDir || "";
      SAVE_FILENAME_PREFIX = v.saveFilenamePrefix || SAVE_DEFAULTS.saveFilenamePrefix;
    });
  } catch (e) { /* storage may be unavailable very early */ }
}
loadAutoMode();
chrome.runtime.onStartup && chrome.runtime.onStartup.addListener(loadAutoMode);
chrome.runtime.onInstalled && chrome.runtime.onInstalled.addListener(loadAutoMode);

// UTF-8 safe base64 (btoa alone breaks on non-Latin1 bytes in cookies/bodies).
// Service workers have no URL.createObjectURL, so auto-export ships the JSON as
// a data: URL — this keeps multi-byte content intact.
function utf8ToBase64(str) {
  const bytes = new TextEncoder().encode(str);
  let bin = "";
  const CHUNK = 0x8000;
  for (let i = 0; i < bytes.length; i += CHUNK) {
    bin += String.fromCharCode.apply(null, bytes.subarray(i, i + CHUNK));
  }
  return btoa(bin);
}

// Response bodies can be large; cap the per-body capture to keep exports sane.
const MAX_BODY_CAPTURE_BYTES = 5 * 1024 * 1024;

// tabId -> { attached, requests: Map(requestId -> record) }
const sessions = new Map();

function classify(url) {
  const u = url || "";
  if (ARKOSE_RE.test(u)) return "arkose";
  if (ROBLOX_CHALLENGE_RE.test(u)) return "roblox-challenge";
  if (ROBLOX_RE.test(u)) return "roblox";
  return "other";
}

function ensureSession(tabId) {
  let s = sessions.get(tabId);
  if (!s) {
    s = { attached: false, requests: new Map(), autoExported: false };
    sessions.set(tabId, s);
  }
  return s;
}

// Build the SAME export envelope the popup uses (schema_version 2.0.0) so the
// auto-downloaded file is byte-compatible with the manual Export JSON path and
// existing diff tooling consumes it unchanged.
function buildExportPayload(tabId, records) {
  return {
    captured_at: new Date().toISOString(),
    tab_id: tabId,
    record_count: records.length,
    schema_version: "2.0.0",
    note:
      "Full on-wire HTTP capture via CDP (every request). wireRequestHeaders/wireResponseHeaders = authoritative header order/values. postData = raw request body. responseBody = response (base64: prefix when binary). category = arkose|roblox-challenge|roblox|other. topology_truth attached to /fc/gt2/. WARNING: contains real cookies/tokens (.ROBLOSECURITY, ARID) — handle as secret, redact before sharing.",
    records,
  };
}

// POST the capture JSON to the local receiver. The receiver writes it into the
// configured folder (sent via X-Save-Dir / X-Filename headers) and returns the
// final path. This is the WebView2-friendly path: a plain fetch works inside an
// embedded WebView2 even though chrome.downloads with an absolute dir does not.
async function saveViaHttp(json, filename) {
  const headers = {
    "Content-Type": "application/json",
    "X-Filename": filename,
  };
  if (SAVE_DIR) headers["X-Save-Dir"] = SAVE_DIR;
  const resp = await fetch(SAVE_ENDPOINT, { method: "POST", headers, body: json });
  if (!resp.ok) throw new Error("receiver HTTP " + resp.status);
  let info = null;
  try { info = await resp.json(); } catch (e) { /* receiver may return plain text */ }
  return (info && info.path) || filename;
}

async function saveViaDownload(json, filename) {
  const dataUrl = "data:application/json;base64," + utf8ToBase64(json);
  // When SAVE_DIR is set we still pass it as a RELATIVE subfolder under Downloads
  // (the only thing chrome.downloads accepts); absolute dirs need the http path.
  const name = filename;
  return await new Promise((resolve, reject) => {
    chrome.downloads.download({ url: dataUrl, filename: name, saveAs: false }, (id) => {
      const err = chrome.runtime.lastError;
      if (err) reject(new Error(err.message));
      else resolve(id);
    });
  });
}

// Auto-export the current capture for a tab. Triggered once per session when a
// /challenge/continue finishes with HTTP 200. Honours SAVE_MODE so it works on
// WebView2 (http) as well as plain Chrome (download).
async function autoExport(tabId, reason) {
  const s = sessions.get(tabId);
  if (!s || s.autoExported) return;
  s.autoExported = true; // guard against double-firing on retries
  const records = Array.from(s.requests.values());
  const payload = buildExportPayload(tabId, records);
  payload.auto_export = { reason: reason || "continue-200", at: new Date().toISOString() };
  const json = JSON.stringify(payload, null, 2);
  const stamp = new Date().toISOString().replace(/[:.]/g, "-");
  const filename = `${SAVE_FILENAME_PREFIX}-${stamp}.json`;

  let httpOk = false;
  let savedPath = filename;
  if (SAVE_MODE === "http" || SAVE_MODE === "both") {
    try {
      savedPath = await saveViaHttp(json, filename);
      httpOk = true;
    } catch (e) {
      console.warn("auto-export http save failed:", e && e.message);
    }
  }
  if (SAVE_MODE === "download" || SAVE_MODE === "both" || (!httpOk && SAVE_MODE === "http")) {
    // Fallback to download if http failed (or if download was requested). On a
    // pure WebView2 host the download may also fail silently — http is primary.
    try {
      await saveViaDownload(json, filename);
    } catch (e) {
      console.warn("auto-export download save failed:", e && e.message);
      if (!httpOk) {
        s.autoExported = false; // both paths failed: re-arm for a later 200
        return;
      }
    }
  }

  try {
    chrome.action.setBadgeText({ tabId, text: "OK" });
    chrome.action.setBadgeBackgroundColor({ tabId, color: "#1f6f4a" });
  } catch (e) { /* badge is best-effort */ }
  console.log("auto-export saved:", savedPath, "(mode=" + SAVE_MODE + ")");
}

async function cdp(tabId, method, params) {
  return new Promise((resolve, reject) => {
    chrome.debugger.sendCommand({ tabId }, method, params || {}, (result) => {
      const err = chrome.runtime.lastError;
      if (err) reject(new Error(err.message));
      else resolve(result);
    });
  });
}

async function startCapture(tabId) {
  const s = ensureSession(tabId);
  if (s.attached) return { ok: true, already: true };

  await new Promise((resolve, reject) => {
    chrome.debugger.attach({ tabId }, PROTOCOL_VERSION, () => {
      const err = chrome.runtime.lastError;
      if (err) reject(new Error(err.message));
      else resolve();
    });
  });
  s.attached = true;
  await cdp(tabId, "Network.enable", {
    maxResourceBufferSize: 200 * 1024 * 1024,
    maxTotalBufferSize: 500 * 1024 * 1024,
  });
  // Page + Runtime expose the REAL frame topology (frame tree +
  // window.location.ancestorOrigins) — the BDA window__tree_structure /
  // window__tree_index / window__ancestor_origins ground-truth.
  try { await cdp(tabId, "Page.enable", {}); } catch (e) { /* ignore */ }
  try { await cdp(tabId, "Runtime.enable", {}); } catch (e) { /* ignore */ }
  return { ok: true };
}

// Capture the live frame topology: the full frame tree (urls + nesting) plus,
// per frame, the values a real browser puts in the BDA topology fields —
// ancestorOrigins, nesting depth, iframe flag — and any persisted ARID
// (localStorage "x-ark-arid*" + the IndexedDB "key-val-store").
async function captureTopology(tabId) {
  const out = { capturedAt: new Date().toISOString(), frameTree: null, arkoseFrames: [] };
  let tree;
  try {
    tree = await cdp(tabId, "Page.getFrameTree", {});
  } catch (e) {
    out.error = "getFrameTree failed: " + (e && e.message);
    return out;
  }

  const flat = [];
  function walk(node, parentId, depth) {
    const f = node.frame || {};
    flat.push({ frameId: f.id, parentId: parentId || null, url: f.url || "", depth });
    (node.childFrames || []).forEach((c) => walk(c, f.id, depth + 1));
  }
  if (tree && tree.frameTree) walk(tree.frameTree, null, 0);
  out.frameTree = flat;

  const expr =
    "JSON.stringify({" +
    "ancestorOrigins: Array.prototype.slice.call(window.location.ancestorOrigins||[])," +
    "href: window.location.href," +
    "referrer: document.referrer," +
    "depth: (function(){var d=0,w=window;try{while(w!==w.parent){d++;w=w.parent;}}catch(e){}return d;})()," +
    "topHref: (function(){try{return window.top.location.href;}catch(e){return '<cross-origin>';}})()," +
    "inIframe: window.self!==window.top," +
    "aridLocalStorage: (function(){try{var o={};for(var i=0;i<localStorage.length;i++){var k=localStorage.key(i);if(/arid|x-ark/i.test(k))o[k]=localStorage.getItem(k);}return o;}catch(e){return {_err:String(e)};}})()," +
    "allLocalStorageKeys: (function(){try{var a=[];for(var i=0;i<localStorage.length;i++)a.push(localStorage.key(i));return a;}catch(e){return [];}})()" +
    "})";

  const idbExpr =
    "(async function(){try{" +
    "var dbs=(indexedDB.databases?await indexedDB.databases():[]);" +
    "var out={databases:dbs.map(function(d){return d.name;}),stores:{}};" +
    "for(var di=0;di<dbs.length;di++){var nm=dbs[di].name;" +
    "await new Promise(function(res){var rq=indexedDB.open(nm);rq.onsuccess=function(){var db=rq.result;try{var names=Array.prototype.slice.call(db.objectStoreNames);" +
    "var tx=db.transaction(names,'readonly');var pending=names.length;if(!pending){res();return;}" +
    "names.forEach(function(sn){var st=tx.objectStore(sn);var gr=st.getAll();var kr=st.getAllKeys();" +
    "gr.onsuccess=function(){kr.onsuccess=function(){out.stores[nm+'/'+sn]={keys:kr.result,values:gr.result};if(--pending<=0)res();};};" +
    "gr.onerror=function(){if(--pending<=0)res();};});}catch(e){out.stores[nm]={_err:String(e)};res();}};rq.onerror=function(){res();};});}" +
    "return out;}catch(e){return {_err:String(e)};}})()";

  for (const fr of flat) {
    const isChallenge = /arkoselabs|enforcement|\/fc\/|funcaptcha|challenge\/cdn|hybrid/i.test(fr.url || "");
    try {
      const ctx = await cdp(tabId, "Page.createIsolatedWorld", {
        frameId: fr.frameId,
        worldName: "wirecap",
        grantUniveralAccess: false,
      });
      const ev = await cdp(tabId, "Runtime.evaluate", {
        expression: expr,
        contextId: ctx && ctx.executionContextId,
        returnByValue: true,
      });
      let parsed = null;
      try { parsed = JSON.parse(ev && ev.result && ev.result.value); } catch (_) { /* keep raw */ }

      let idbDump = null;
      try {
        const idbEv = await cdp(tabId, "Runtime.evaluate", {
          expression: idbExpr,
          contextId: ctx && ctx.executionContextId,
          returnByValue: true,
          awaitPromise: true,
        });
        idbDump = idbEv && idbEv.result && idbEv.result.value;
      } catch (_) { /* idb may be cross-origin / blocked */ }

      out.arkoseFrames.push({ frameId: fr.frameId, url: fr.url, depth: fr.depth, isChallenge, topology: parsed || (ev && ev.result && ev.result.value) || null, indexedDB: idbDump });
    } catch (e) {
      out.arkoseFrames.push({ frameId: fr.frameId, url: fr.url, depth: fr.depth, isChallenge, error: String(e && e.message) });
    }
  }
  return out;
}

async function stopCapture(tabId) {
  const s = sessions.get(tabId);
  if (s && s.attached) {
    try { await cdp(tabId, "Network.disable", {}); } catch (e) { /* ignore */ }
    try { await cdp(tabId, "Page.disable", {}); } catch (e) { /* ignore */ }
    try { await cdp(tabId, "Runtime.disable", {}); } catch (e) { /* ignore */ }
    await new Promise((resolve) => chrome.debugger.detach({ tabId }, () => resolve()));
    s.attached = false;
  }
  return { ok: true };
}

// Convert a CDP headers object (insertion-ordered) into an ordered array so the
// exact on-wire header sequence is preserved in the export.
function headersToOrderedArray(headersObj) {
  if (!headersObj || typeof headersObj !== "object") return [];
  return Object.keys(headersObj).map((name) => ({ name, value: String(headersObj[name]) }));
}

chrome.debugger.onEvent.addListener((source, method, params) => {
  const tabId = source.tabId;
  if (tabId == null) return;
  const s = sessions.get(tabId);
  if (!s || !s.attached) return;

  if (method === "Network.requestWillBeSent") {
    const url = params.request && params.request.url;
    // No endpoint filter: capture EVERY request.
    const rec = s.requests.get(params.requestId) || {};
    rec.requestId = params.requestId;
    rec.url = url;
    rec.category = classify(url);
    rec.method = params.request.method;
    rec.requestTime = params.wallTime;
    rec.documentURL = params.documentURL;
    rec.type = params.type;
    rec.initiator = params.initiator;
    rec.requestHeadersHL = headersToOrderedArray(params.request.headers);
    rec.hasPostData = !!params.request.hasPostData;
    if (params.request.postData) rec.postData = params.request.postData;
    s.requests.set(params.requestId, rec);

    if (rec.hasPostData && rec.postData == null) {
      cdp(tabId, "Network.getRequestPostData", { requestId: params.requestId })
        .then((res) => {
          const r = s.requests.get(params.requestId);
          if (r && res && typeof res.postData === "string") r.postData = res.postData;
        })
        .catch(() => { /* body may be unavailable for some requests */ });
    }

    // On the trust-deciding gt2 POST, snapshot the live frame topology.
    if (GT2_RE.test(url)) {
      captureTopology(tabId)
        .then((topo) => {
          const r = s.requests.get(params.requestId);
          if (r) r.topology_truth = topo;
        })
        .catch(() => { /* non-fatal */ });
    }
  } else if (method === "Network.requestWillBeSentExtraInfo") {
    const rec = s.requests.get(params.requestId);
    if (!rec) return;
    rec.wireRequestHeaders = headersToOrderedArray(params.headers);
    rec.connectTiming = params.connectTiming;
  } else if (method === "Network.responseReceived") {
    const rec = s.requests.get(params.requestId);
    if (!rec) return;
    const resp = params.response || {};
    rec.status = resp.status;
    rec.statusText = resp.statusText;
    rec.responseHeaders = headersToOrderedArray(resp.headers);
    rec.remoteIPAddress = resp.remoteIPAddress;
    rec.protocol = resp.protocol;
    rec.mimeType = resp.mimeType;
    // AUTO-EXPORT trigger: the captcha token was accepted at the Roblox redeem
    // step. Fire once the continue response is observed with HTTP 200.
    if (AUTO_MODE && CONTINUE_RE.test(rec.url || "") && resp.status === 200) {
      autoExport(tabId, "continue-200");
    }
  } else if (method === "Network.responseReceivedExtraInfo") {
    const rec = s.requests.get(params.requestId);
    if (!rec) return;
    rec.wireResponseHeaders = headersToOrderedArray(params.headers);
    rec.statusCodeExtra = params.statusCode;
    // Fallback auto-export path: some responses surface their status here first.
    if (AUTO_MODE && CONTINUE_RE.test(rec.url || "") && params.statusCode === 200) {
      autoExport(tabId, "continue-200");
    }
  } else if (method === "Network.loadingFinished") {
    const rec = s.requests.get(params.requestId);
    if (!rec) return;
    rec.done = true;
    rec.encodedDataLength = params.encodedDataLength;
    // Capture the response body for EVERY request (capped). Some bodies are
    // binary or evicted from the buffer; those are skipped gracefully.
    if (typeof params.encodedDataLength === "number" &&
        params.encodedDataLength > MAX_BODY_CAPTURE_BYTES) {
      rec.responseBody = `<skipped: ${params.encodedDataLength} bytes exceeds ${MAX_BODY_CAPTURE_BYTES}>`;
      return;
    }
    cdp(tabId, "Network.getResponseBody", { requestId: params.requestId })
      .then((res) => {
        if (res && typeof res.body === "string") {
          rec.responseBody = res.base64Encoded ? `base64:${res.body}` : res.body;
        }
      })
      .catch(() => { /* binary / evicted */ });
  } else if (method === "Network.loadingFailed") {
    const rec = s.requests.get(params.requestId);
    if (!rec) return;
    rec.done = true;
    rec.failed = true;
    rec.errorText = params.errorText;
    rec.canceled = params.canceled;
  }
});

chrome.debugger.onDetach.addListener((source) => {
  const s = sessions.get(source.tabId);
  if (s) s.attached = false;
});
chrome.tabs.onRemoved.addListener((tabId) => sessions.delete(tabId));

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    try {
      if (msg.cmd === "start") {
        const r = await startCapture(msg.tabId);
        sendResponse(r);
      } else if (msg.cmd === "stop") {
        const r = await stopCapture(msg.tabId);
        sendResponse(r);
      } else if (msg.cmd === "status") {
        const s = sessions.get(msg.tabId);
        let counts = { arkose: 0, "roblox-challenge": 0, roblox: 0, other: 0 };
        if (s) {
          for (const rec of s.requests.values()) {
            counts[rec.category] = (counts[rec.category] || 0) + 1;
          }
        }
        sendResponse({
          attached: !!(s && s.attached),
          count: s ? s.requests.size : 0,
          counts,
        });
      } else if (msg.cmd === "export") {
        const s = sessions.get(msg.tabId);
        const records = s ? Array.from(s.requests.values()) : [];
        sendResponse({ ok: true, records });
      } else if (msg.cmd === "clear") {
        const s = sessions.get(msg.tabId);
        if (s) s.requests.clear();
        sendResponse({ ok: true });
      } else if (msg.cmd === "setAuto") {
        AUTO_MODE = !!msg.value;
        try { chrome.storage.local.set({ autoMode: AUTO_MODE }); } catch (e) { /* ignore */ }
        sendResponse({ ok: true, autoMode: AUTO_MODE });
      } else if (msg.cmd === "getAuto") {
        sendResponse({ ok: true, autoMode: AUTO_MODE });
      } else if (msg.cmd === "getConfig") {
        sendResponse({
          ok: true,
          autoMode: AUTO_MODE,
          saveMode: SAVE_MODE,
          saveEndpoint: SAVE_ENDPOINT,
          saveDir: SAVE_DIR,
          saveFilenamePrefix: SAVE_FILENAME_PREFIX,
        });
      } else if (msg.cmd === "setConfig") {
        const c = msg.config || {};
        if (typeof c.autoMode === "boolean") AUTO_MODE = c.autoMode;
        if (typeof c.saveMode === "string") SAVE_MODE = c.saveMode;
        if (typeof c.saveEndpoint === "string") SAVE_ENDPOINT = c.saveEndpoint.trim() || SAVE_DEFAULTS.saveEndpoint;
        if (typeof c.saveDir === "string") SAVE_DIR = c.saveDir.trim();
        if (typeof c.saveFilenamePrefix === "string") {
          SAVE_FILENAME_PREFIX = c.saveFilenamePrefix.trim() || SAVE_DEFAULTS.saveFilenamePrefix;
        }
        try {
          chrome.storage.local.set({
            autoMode: AUTO_MODE,
            saveMode: SAVE_MODE,
            saveEndpoint: SAVE_ENDPOINT,
            saveDir: SAVE_DIR,
            saveFilenamePrefix: SAVE_FILENAME_PREFIX,
          });
        } catch (e) { /* ignore */ }
        sendResponse({
          ok: true,
          autoMode: AUTO_MODE,
          saveMode: SAVE_MODE,
          saveEndpoint: SAVE_ENDPOINT,
          saveDir: SAVE_DIR,
          saveFilenamePrefix: SAVE_FILENAME_PREFIX,
        });
      } else {
        sendResponse({ ok: false, error: "unknown cmd" });
      }
    } catch (e) {
      sendResponse({ ok: false, error: String((e && e.message) || e) });
    }
  })();
  return true; // async
});

// ---------------------------------------------------------------------------
// AUTO-ATTACH: when AUTO_MODE is on, attach the debugger to any tab the moment
// it navigates to the Roblox challenge surface (.../challenge/cdn/hybrid). This
// removes the need to click Start — the capture is live before the gt2 POST is
// sent. We match on URL path only; the query (per-challenge blob/id) is ignored.
// ---------------------------------------------------------------------------
function maybeAutoAttach(tabId, url) {
  if (!AUTO_MODE || !url) return;
  if (!HYBRID_RE.test(url) && !CONTINUE_RE.test(url)) return;
  const s = sessions.get(tabId);
  if (s && s.attached) return;
  startCapture(tabId)
    .then(() => {
      autoAttachedTabs.add(tabId);
      try {
        chrome.action.setBadgeText({ tabId, text: "REC" });
        chrome.action.setBadgeBackgroundColor({ tabId, color: "#6f1f2a" });
      } catch (e) { /* badge best-effort */ }
    })
    .catch(() => { /* another debugger (DevTools) may be attached; ignore */ });
}

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  // changeInfo.url fires on SPA / same-doc navigations; tab.url covers the rest.
  const url = changeInfo.url || (tab && tab.url) || "";
  maybeAutoAttach(tabId, url);
});

// Catch challenge frames that load via committed navigations (covers the hybrid
// page loading inside the tab without a top-level tabs.onUpdated url change).
if (chrome.webNavigation && chrome.webNavigation.onCommitted) {
  chrome.webNavigation.onCommitted.addListener((details) => {
    maybeAutoAttach(details.tabId, details.url || "");
  });
}
