# Full Wire Capture Extension

Bắt **chính xác bytes trên wire** của **MỌI** request mà tab tạo ra (header thật,
đúng thứ tự, kèm request body **và** response body) và xuất JSON làm ground-truth
để diff với solver. Không lọc endpoint — toàn bộ API surface (Arkose + Roblox +
mọi thứ khác) đều được ghi, và được gắn nhãn `category` để dễ đọc.

Dùng `chrome.debugger` (Chrome DevTools Protocol), KHÔNG dùng `webRequest` — vì
webRequest không đọc được request/response body và bị strip `sec-ch-ua*`. CDP cho
thấy đúng cái browser đặt lên dây.

## Cài

1. Mở `chrome://extensions`
2. Bật **Developer mode** (góc trên phải)
3. **Load unpacked** → chọn thư mục `tools/gt2-capture-extension`
4. Ghim extension cho dễ bấm

## Dùng

1. Mở tab Roblox (trang kích hoạt captcha — login/signup/join).
2. Bấm icon extension → **Start** (đính debugger vào tab; Chrome hiện banner
   "đang debug", kệ nó).
3. Kích hoạt / giải Arkose challenge như bình thường. Bộ đếm `reqs` + breakdown
   (`ark · rbx-chal · rbx · other`) sẽ tăng.
4. Bấm **Export JSON** → lưu file `full-wire-capture-<timestamp>.json`.
5. Đưa file đó cho agent để diff toàn bộ API thật vs solver.

> Để Start chạy xuyên suốt cả luồng (bootstrap → gt2 → /fc/a/ → /fc/ca/ →
> `/challenge/continue`) để có đủ chuỗi request, gồm cả endpoint 403.

> ⚠️ **CẢNH BÁO SECRET:** file export chứa **cookie/token thật** (`.ROBLOSECURITY`,
> `ARID`, csrf, session). Coi như bí mật — **redact trước khi chia sẻ/commit**.

## URL được bắt

**TẤT CẢ.** Không còn bộ lọc. Mỗi request được gắn `category`:

- `arkose` — `/fc/gt2/`, `/fc/a/`, `/fc/ca/`, `/v2/<key>/api.js`, `enforcement.<hash>.html`, `/pows/`, mọi host `arkoselabs`
- `roblox-challenge` — `/challenge/...continue`, `apis.roblox.com/challenge`, `challenge/cdn`, `hybrid`
- `roblox` — mọi host `roblox.com`/`rbxcdn.com`
- `other` — còn lại

## Cấu trúc JSON (mỗi record)

| field | nghĩa |
|---|---|
| `url`, `method`, `type`, `category` | request line + nhãn phân loại |
| `wireRequestHeaders` | **header thật + đúng thứ tự** (authoritative — gồm sec-ch-ua, cookie) |
| `requestHeadersHL` | header "high-level" (tham khảo) |
| `postData` | body thô (vd `c=...&public_key=...&data[blob]=...`) |
| `status`, `wireResponseHeaders`, `responseBody` | phản hồi (body có prefix `base64:` khi nhị phân; `<skipped: N bytes>` nếu > 5MB) |
| `remoteIPAddress`, `protocol`, `encodedDataLength` | h2/h3, IP đích, kích thước |
| `failed`, `errorText` | nếu request lỗi/bị huỷ |
| `topology_truth` | **frame tree thật + `ancestorOrigins`/depth của iframe Arkose** (chỉ gắn trên request `/fc/gt2/`) |

Quan trọng nhất: **`wireRequestHeaders` + `postData` + `responseBody`** của mọi
endpoint — đủ để dựng lại + diff toàn bộ flow solver đang mô phỏng.

## `topology_truth` — ground-truth window tree

Chỉ snapshot trên request `/fc/gt2/`. Dùng để diff với cái Go client hardcode
(`ancestor_origins=["roblox.com","roblox.com"]`, `tree_structure="[[]]"`,
`tree_index=[0]`):

```json
"topology_truth": {
  "frameTree": [ {"frameId","parentId","url","depth"}, ... ],
  "arkoseFrames": [
    { "url": ".../enforcement...html", "depth": N,
      "topology": { "ancestorOrigins": [...], "href": "...",
                    "referrer": "...", "depth": N, "inIframe": true } }
  ]
}
```

Cần xác nhận: `len(ancestorOrigins)` thật vs `tree_structure`/`tree_index` Go gửi
có khớp depth không. `bda_inapp.py` (capture in-app thật) ghi chú iframe web =
`"[[],[]]"`, nhưng Go đang gửi `"[[]]"` — `topology_truth` sẽ phân xử cái nào đúng.

## ARID cold-start capture

`topology_truth.arkoseFrames[]` giờ kèm:
- `topology.aridLocalStorage` — mọi localStorage key khớp `arid`/`x-ark` (đây là nửa `ls` của ARID).
- `topology.allLocalStorageKeys` — toàn bộ key (để soi key Arkose dùng).
- `indexedDB` — dump `databases` + `stores` (gồm `key-val-store` chứa nửa `idb` của ARID).

**Cold-start ARID tươi:** xoá sạch dữ liệu site Roblox (DevTools → Application → Clear storage) → giải captcha → Export. `aridLocalStorage`/`indexedDB` sẽ chứa ARID **mới server cấp** + response request nào set header `x-ark-arid` (xem `wireResponseHeaders`). Đó là ARID tươi để seed/relay.


