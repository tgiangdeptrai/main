// GT2 Wire Capture — popup controller

async function activeTabId() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab ? tab.id : null;
}

function send(cmd, extra) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(Object.assign({ cmd }, extra || {}), (r) => resolve(r || {}));
  });
}

const dot = document.getElementById("dot");
const statusText = document.getElementById("statusText");
const countEl = document.getElementById("count");
const breakdownEl = document.getElementById("breakdown");
const autoEl = document.getElementById("autoMode");

async function refreshAuto() {
  const r = await send("getAuto", {});
  if (autoEl && typeof r.autoMode === "boolean") autoEl.checked = r.autoMode;
}

if (autoEl) {
  autoEl.addEventListener("change", async () => {
    await send("setAuto", { value: autoEl.checked });
  });
}

async function refresh() {
  const tabId = await activeTabId();
  if (tabId == null) return;
  const r = await send("status", { tabId });
  dot.classList.toggle("on", !!r.attached);
  statusText.textContent = r.attached ? "capturing" : "idle";
  countEl.textContent = r.count || 0;
  const c = r.counts || {};
  if (breakdownEl) {
    breakdownEl.textContent =
      `ark ${c.arkose || 0} · rbx-chal ${c["roblox-challenge"] || 0} · rbx ${c.roblox || 0} · other ${c.other || 0}`;
  }
}

document.getElementById("start").addEventListener("click", async () => {
  const tabId = await activeTabId();
  const r = await send("start", { tabId });
  if (!r.ok) statusText.textContent = "err: " + (r.error || "?");
  refresh();
});

document.getElementById("stop").addEventListener("click", async () => {
  const tabId = await activeTabId();
  await send("stop", { tabId });
  refresh();
});

document.getElementById("clear").addEventListener("click", async () => {
  const tabId = await activeTabId();
  await send("clear", { tabId });
  refresh();
});

document.getElementById("export").addEventListener("click", async () => {
  const tabId = await activeTabId();
  const r = await send("export", { tabId });
  if (!r.ok) {
    statusText.textContent = "export err: " + (r.error || "?");
    return;
  }
  const payload = {
    captured_at: new Date().toISOString(),
    tab_id: tabId,
    record_count: r.records.length,
    schema_version: "2.0.0",
    note: "Full on-wire HTTP capture via CDP (every request). wireRequestHeaders/wireResponseHeaders = authoritative header order/values. postData = raw request body. responseBody = response (base64: prefix when binary). category = arkose|roblox-challenge|roblox|other. topology_truth attached to /fc/gt2/. WARNING: contains real cookies/tokens (.ROBLOSECURITY, ARID) — handle as secret, redact before sharing.",
    records: r.records,
  };
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const stamp = new Date().toISOString().replace(/[:.]/g, "-");
  await chrome.downloads.download({
    url,
    filename: `full-wire-capture-${stamp}.json`,
    saveAs: true,
  });
  setTimeout(() => URL.revokeObjectURL(url), 10000);
});

setInterval(refresh, 1000);
refresh();
refreshAuto();
